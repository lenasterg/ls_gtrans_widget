﻿=== Ls Gtrans Widget ===
Contributors: lenasterg, NTS on cti.gr
Tags: google translate, widget
Requires at least: 3.6
Tested up to: 4.2.2
Stable tag: 1.0
License:  GNU General Public License 3.0 or newer (GPL)
License URI: http://www.gnu.org/licenses/gpl.html

Widget with selectbox to Google translation for the current page. The options are more than 25 European languages.

== Description ==
Do you want an easy way to add google translation to your posts and pages? Does WordPress security restrictions don't let you do it? Then, simple drag and drop this widget to your sidebar to allow your visitors to tranlate the viewed webpage using the translation service from Google. It simple displays a selectbox with more than 25 European languages. When a user selects a language a new window in http://translate.google.com/ opens.
The original language is autodetected.
Multisite ready.

== Installation ==

1. Upload `ls_gtrans_widget` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to your widgets page and drag the widget "Translation in google" into your sidebar panel
Ready!!!

== Frequently Asked Questions ==



== Screenshots ==

1. Widget settings
2. Widget in frontend

== Changelog ==

= 1.0 =
* Initial release.
